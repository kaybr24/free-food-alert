# free-food-alert
web-database to track free food on Wellesley's campus!

Food Guides log in to post information about free food
General users can look at the food posts.
